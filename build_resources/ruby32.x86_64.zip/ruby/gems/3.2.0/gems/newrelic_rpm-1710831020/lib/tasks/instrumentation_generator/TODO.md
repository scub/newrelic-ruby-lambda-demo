# TODO

# - [X] Create instrumentation file

# - [X] Create chain file

# - [X] Create prepend file

# - [X] Create dependency detection file

# - [X] Add config to default source

# - [X] Create multiverse suite

# - [X] Create Envfile

# - [X] Create test file with examples

# - [X] Create option for method names to instrument

# - [X] Add entry to newrelic.yml

# - [ ] Append a new method to instrument to an existing instrumentation class (with tests?)

# - [ ] Documentation: examples of what to add in each gap (Good examples of tests, instrumentation, etc. as comments to guide users)

# - [ ] Handle multi-word gem names (camel case for classes, handle hyphens, concurrent-ruby as example)

# - [ ] Allow multiple method arguments to be passed to the command line

# - [ ] Add tests for the instrumentation_generator code

# - [ ] See if instrumentation PRs can get automatically generated when an already instrumented library adds methods to its codebase
